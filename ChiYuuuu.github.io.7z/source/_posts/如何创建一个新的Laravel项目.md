---
title: 常用网页工具
date:  2022-04-04
categories:  浏览器
toc: true
tags:
-  在线工具

---

## 图片处理

[**TinyPNG**](https://tinypng.com/)
支持WebP、PNG 、JPEG;图片最多20张,最大5MB<!--more-->

[**iloveimg**](https://www.iloveimg.com/compress-image)
支持JPG、GIF、PNG、SVG;图片最大60MB左右

[**图片转base64**](https://c.runoob.com/front-end/59/)
可直接复制转换后的html、css代码

## 文本工具

[**英文大小写转换**](https://www.iamwawa.cn/daxiaoxie.html)

[**全角半角转换**](https://www.iamwawa.cn/quanjiaobanjiao.html)

